package com.example.demo.repository;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Creaacc;





	@Repository
	public interface CreaaccRepository extends JpaRepository<Creaacc, Integer> {

	}
	