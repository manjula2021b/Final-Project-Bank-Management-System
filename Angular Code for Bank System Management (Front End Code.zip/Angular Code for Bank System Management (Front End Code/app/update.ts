export class Update {
id!:BigInteger;
name!:string;
email!:string;
phno!:string;
balance!:BigInteger;
// accountnumber!:BigInteger;
    
}
