export class Login {
    id!:string;
    username!:string;
    password!:string;
}
