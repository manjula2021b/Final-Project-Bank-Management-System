export class createacc {
    name!:string;
    email!:string;
    phno!:string;
    // accountnumber!:BigInteger;
}