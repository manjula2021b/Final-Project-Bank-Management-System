export class Userdetails {
    name!:string;
    email!:string;
    phno!:string;
    id!:BigInteger;
    balance!:BigInteger;
    // accountnumber!:BigInteger;
}
